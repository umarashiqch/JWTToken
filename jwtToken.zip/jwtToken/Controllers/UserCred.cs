﻿namespace jwtToken.Controllers
{
    public class UserCred
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}